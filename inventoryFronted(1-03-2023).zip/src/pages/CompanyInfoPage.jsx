import React from "react";
import EditCompanyInfo from "../Components/Company/EditCompanyInfo/EditCompanyInfo";

function CompanyInfoPage() {
  return (
    <div>
      <EditCompanyInfo />
    </div>
  );
}

export default CompanyInfoPage;

import React from "react";
import UserDeleteList from "../../Components/User/userDelte/UserDeleteList";

function UserDeleteListPage() {
  return (
    <div>
      <UserDeleteList />
    </div>
  );
}

export default UserDeleteListPage;

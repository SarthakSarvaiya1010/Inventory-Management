import React from "react";

function HomePageAdmin() {
  return <div>HomePage</div>;
}

export default HomePageAdmin;

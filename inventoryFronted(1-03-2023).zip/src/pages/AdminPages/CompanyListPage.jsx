import React from "react";
import CompanyList from "../../Components/Company/CompanyList/CompanyList";

function CompanyListPage() {
  return (
    <div>
      <CompanyList />
    </div>
  );
}

export default CompanyListPage;

import React from "react";
import UserList from "../../Components/User/UserList/UserList";

function UserListPage() {
  return (
    <div>
      <UserList />
    </div>
  );
}

export default UserListPage;

import React from "react";
import AddProduct from "../Components/Product/AddProduct/AddProduct";

function AddProductPage() {
  return (
    <div>
      <AddProduct />
    </div>
  );
}

export default AddProductPage;

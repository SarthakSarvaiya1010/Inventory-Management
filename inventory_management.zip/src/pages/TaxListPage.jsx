import React from "react";
import TaxList from "../Components/Tax/TaxList/TaxList";

function TaxListPage() {
  return (
    <div>
      <TaxList />
    </div>
  );
}

export default TaxListPage;

import React from "react";
import CustomerList from "../Components/Customer/CustomerList/CustomerList";

function CustomerListPage() {
  return (
    <div>
      <CustomerList />
    </div>
  );
}

export default CustomerListPage;

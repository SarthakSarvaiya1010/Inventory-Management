import React from "react";
import AddUser from "../../Components/User/AddUser/AddUser";

function AddUserPage() {
  return (
    <div>
      <AddUser />
    </div>
  );
}

export default AddUserPage;

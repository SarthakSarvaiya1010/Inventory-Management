import React from "react";
import AddInvoice from "../Components/Invoice/AddInvoice/AddInvoice";

function AddInvoicePage() {
  return (
    <div>
      <AddInvoice />
    </div>
  );
}

export default AddInvoicePage;

import React from "react";
import DeletedProductList from "../Components/Product/DeletedProductList/DeletedProductList";

function DeletedProductListPage() {
  return (
    <div>
      <DeletedProductList />
    </div>
  );
}

export default DeletedProductListPage;

import React from "react";
import DeletedCustomerList from "../Components/Customer/DeletedCustomerList/DeletedCustomerList";

function DeletedCustomerListPage() {
  return (
    <div>
      <DeletedCustomerList />
    </div>
  );
}

export default DeletedCustomerListPage;

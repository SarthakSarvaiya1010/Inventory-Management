import React from "react";
import DeleteTaxList from "../Components/Tax/DeleteTax/DeleteTaxList";

function DeleteTaxPage() {
  return (
    <div>
      <DeleteTaxList />
    </div>
  );
}

export default DeleteTaxPage;

import React from "react";
import AddTax from "../Components/Tax/AddTax/AddTax";

function AddTaxPage() {
  return (
    <div>
      <AddTax />
    </div>
  );
}

export default AddTaxPage;

import React from "react";
import ProductLisit from "../Components/Product/ProductList/ProductList";

function AddProductPage() {
  return (
    <div>
      <ProductLisit />
    </div>
  );
}

export default AddProductPage;

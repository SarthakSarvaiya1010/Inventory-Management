import React from "react";
import AddCustomer from "../Components/Customer/AddCustomer/AddCustomer";

function AddCustomerPage() {
  return (
    <div>
      <AddCustomer />
    </div>
  );
}

export default AddCustomerPage;

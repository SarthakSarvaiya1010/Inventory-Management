import React from 'react'
import EditInvoice from "../Components/Invoice/EditInvoice/EditInvoice"

export default function EditInvoicePage() {
  return (
    <div>
      <EditInvoice />
    </div>
  )
}

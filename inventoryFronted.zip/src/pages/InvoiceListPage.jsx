import React from "react";
import InvoiceList from "../Components/Invoice/InvoiceList/InvoiceList";

function InvoiceListPage() {
  return (
    <div>
      <InvoiceList />
    </div>
  );
}

export default InvoiceListPage;
